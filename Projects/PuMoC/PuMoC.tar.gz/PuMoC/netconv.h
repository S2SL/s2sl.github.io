/****************************************************************************/
/* netconv.h                                                                */

extern char *nc_rundir;

extern void nc_run_spin(char *args);
extern char* nc_get_path(char *argv0);
