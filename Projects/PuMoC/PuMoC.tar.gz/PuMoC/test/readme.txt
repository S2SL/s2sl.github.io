This directory contains three folders bebop-itp, cmpPDSolver, PDSs and 
some files for quick start.

bebop: is a set of boolean programs each of them equiped with a CTL formula. 
The boolean programs are taken from SLAM, and the copyright of these boolean programs
belong to Mricrosoft Inc. .


cmpPDSolver: is a set of Pushdown systems generated from the benchmark (Java programs) 
of PDSolver by Jimpletopdsolver. 


PDSs: is a set of random gengerated pushdown systems each of them
equiped with a randam generated CTL formula.

