#ifndef __RATIONALTREATMENT_H
#define __RATIONALTREATMENT_H
#include "../system/system.h"
int ppcmOfExpr(expr expression, int p);
void rationalsToInteger(struct system * syst);
#endif
