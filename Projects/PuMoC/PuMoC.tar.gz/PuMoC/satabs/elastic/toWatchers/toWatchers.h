#ifndef __TOWATCHERS_H
#define __TOWATCHERSL_H
#include "../system/system.h"

void toWatchers(struct system * syst);

#endif
