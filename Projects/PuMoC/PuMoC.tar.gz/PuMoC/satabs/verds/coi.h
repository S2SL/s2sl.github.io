#ifndef coi_h
#define coi_h
/***********************************************************************/
#define LOCAL
#define GLOBAL
/***********************************************************************/
#include "issat.h"
#include "tree.h"
#include "form.h"
#include "p2bp.h"
#include "bp2s.h"
/***********************************************************************/
#include "wfcoi.h"
#endif
