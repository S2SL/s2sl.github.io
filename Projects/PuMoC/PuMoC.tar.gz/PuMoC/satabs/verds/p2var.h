#ifndef p2var_h
#define p2var_h
/***********************************************************************/
typedef struct _TBDtv { 
	int count; 
	int *ivalue; 
	int *rtable;
	char **name; 
} TBDtv; 
/************************************************************************/
/*
typedef struct _TBDtree { 
	char *node; 
	struct _TBDtree *left; 
	struct _TBDtree *right; 
} TBDtree; 
/***********************************************************************/
#endif
