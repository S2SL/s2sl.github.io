#ifndef main_h
#define main_h
/***********************************************************************/
#include "tree.h"
#include "form.h"
#include "f2p.h"
#include "p2bp.h"
#include "bp2s.h"
#include "bp2q.h"
#include "coi.h"
#include "opt1.h"
/*
#include "config.h"
/***********************************************************************/
#define skipword(ll) \
	while (*ll&&*ll!=' ') ll++; while (*ll==' ') ll++;
/***********************************************************************/
#include "wfmain.h"
#endif
